import dotenv from "dotenv";
dotenv.config();

import express, { Request, Response, NextFunction } from "express";
import cors from "cors";
import compression from "compression";
import path from "path";
import { fileURLToPath } from "url";
import { connectDatabase, closeDatabase } from "./src/server/config/database.js";
import apiRoutes from "./src/server/routes/api.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000; // Standard AI Studio container port

// 1. Compression Middleware to reduce network transfer size and GC pressure
app.use(compression());

// 2. Flexible CORS Configuration (supports preview iframes and custom origins)
app.use(
  cors({
    origin: (origin, callback) => {
      // Allow all origins including undefined (mobile apps, curl, same-origin, iframe)
      callback(null, true);
    },
    credentials: true,
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization", "X-Requested-With"],
  })
);

// 3. Payload Limit Protection: Prevent memory exhaustion from oversized JSON bodies
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true, limit: "2mb" }));

// 4. API Routes
app.use("/api", apiRoutes);

// 5. Global Error Handler (prevents unhandled rejections from crashing the process)
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  console.error("🔥 [Unhandled Server Error]:", err);
  res.status(err.status || 500).json({
    status: "error",
    message: err.message || "Internal server error",
    timestamp: new Date().toISOString(),
  });
});

async function startServer() {
  // Non-blocking DB connection: Let HTTP server start instantly!
  connectDatabase().catch((err) => {
    console.warn("ℹ️ Background DB connection notice:", err.message);
  });

  // Vite middleware in development vs static serving in production
  if (process.env.NODE_ENV !== "production") {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  const server = app.listen(PORT, "0.0.0.0", () => {
    console.log(`🚀 TransitFlow Engine online at http://0.0.0.0:${PORT}`);
    console.log(`⚡ Mode: ${process.env.NODE_ENV || "development"} | Memory & Pool Protection Active`);
  });

  // Robust Graceful Shutdown with timeout guard
  let isShuttingDown = false;
  const gracefulShutdown = async (signal: string) => {
    if (isShuttingDown) return;
    isShuttingDown = true;

    console.log(`\n🛑 Received ${signal}. Commencing graceful shutdown...`);

    const forceTimer = setTimeout(() => {
      console.error("⚠️ Forced termination due to shutdown timeout.");
      process.exit(1);
    }, 5000);

    server.close(async () => {
      try {
        await closeDatabase();
        console.log("✅ All sockets, timers, and database connections cleaned up.");
        clearTimeout(forceTimer);
        process.exit(0);
      } catch (err: any) {
        console.error("Error during teardown:", err.message);
        process.exit(1);
      }
    });
  };

  process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
  process.on("SIGINT", () => gracefulShutdown("SIGINT"));
}

startServer().catch((fatalErr) => {
  console.error("Fatal startup error:", fatalErr);
});
