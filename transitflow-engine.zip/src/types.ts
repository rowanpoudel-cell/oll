export interface MemoryStats {
  timestamp: string;
  uptimeSeconds: number;
  rssMb: number;
  heapTotalMb: number;
  heapUsedMb: number;
  heapUsedPercent: number;
  externalMb: number;
  arrayBuffersMb: number;
  heapLimitMb: number;
  gcAvailable: boolean;
  status: "optimal" | "moderate" | "high" | "critical";
  trend: "stable" | "increasing" | "decreasing";
  cacheSize: number;
  cacheMaxItems: number;
  allocationsSimulated: number;
}

export interface DatabaseMetrics {
  status: "connected" | "connecting" | "disconnected" | "error" | "unconfigured";
  uriConfigured: boolean;
  maskedUri: string;
  readyState: number;
  activeConnections: number;
  totalConnectionsCreated: number;
  maxPoolSize: number;
  minPoolSize: number;
  reconnectAttempts: number;
  lastConnectedAt: string | null;
  lastError: string | null;
  mode: "database" | "in-memory-fallback";
}

export interface TransitRoute {
  _id: string;
  routeId: string;
  name: string;
  type: "bus" | "subway" | "tram" | "ferry";
  stopsCount: number;
  frequencyMinutes: number;
  status: "active" | "delayed" | "maintenance";
  color: string;
  createdAt?: string;
}

export interface TransitVehicle {
  _id: string;
  vehicleId: string;
  routeId: string;
  driverName: string;
  passengerOccupancy: number;
  speedKmh: number;
  fuelOrBattery: number;
  status: "in_transit" | "stopped" | "idle" | "out_of_service";
  latitude: number;
  longitude: number;
  lastPingAt: string;
}

export interface AuditIssue {
  id: string;
  title: string;
  severity: "CRITICAL" | "HIGH" | "MEDIUM" | "LOW";
  rootCause: string;
  solutionApplied: string;
}
