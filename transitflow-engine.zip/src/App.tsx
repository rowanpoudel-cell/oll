import { useState, useEffect, useCallback } from "react";
import { Header } from "./components/Header.tsx";
import { MemoryDashboard } from "./components/MemoryDashboard.tsx";
import { DatabaseManager } from "./components/DatabaseManager.tsx";
import { TransitOperations } from "./components/TransitOperations.tsx";
import { StartupAudit } from "./components/StartupAudit.tsx";
import { DatabaseMetrics, MemoryStats } from "./types.ts";

export default function App() {
  const [activeTab, setActiveTab] = useState<"memory" | "database" | "transit" | "audit">("memory");
  const [dbMetrics, setDbMetrics] = useState<DatabaseMetrics | null>(null);
  const [memStats, setMemStats] = useState<MemoryStats | null>(null);
  const [loading, setLoading] = useState(false);

  const fetchSystemMetrics = useCallback(async () => {
    setLoading(true);
    try {
      const [dbRes, memRes] = await Promise.all([
        fetch("/api/system/database"),
        fetch("/api/system/memory"),
      ]);

      if (dbRes.ok) {
        const dbData = await dbRes.json();
        setDbMetrics(dbData);
      }

      if (memRes.ok) {
        const memData = await memRes.json();
        setMemStats(memData);
      }
    } catch (err) {
      console.error("Failed to load telemetry metrics:", err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchSystemMetrics();
    const interval = setInterval(fetchSystemMetrics, 4000);
    return () => clearInterval(interval);
  }, [fetchSystemMetrics]);

  return (
    <div className="min-h-screen bg-[#0A0A0C] text-[#E2E2E2] flex flex-col font-sans selection:bg-blue-600/30 selection:text-blue-200">
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        dbMetrics={dbMetrics}
        memStats={memStats}
        loading={loading}
        onRefresh={fetchSystemMetrics}
      />

      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
        {activeTab === "memory" && (
          <MemoryDashboard memStats={memStats} onRefresh={fetchSystemMetrics} />
        )}

        {activeTab === "database" && (
          <DatabaseManager dbMetrics={dbMetrics} onRefresh={fetchSystemMetrics} />
        )}

        {activeTab === "transit" && <TransitOperations />}

        {activeTab === "audit" && <StartupAudit />}
      </main>

      <footer className="border-t border-[#222226] bg-[#111114] py-4 mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#9CA3AF]">
          <div>
            <span className="font-semibold text-[#E2E2E2]">TransitFlow Engine</span> — Resilient Node.js & Mongoose Runtime
          </div>
          <div className="flex items-center gap-4">
            <span>Port 3000 (0.0.0.0)</span>
            <span>•</span>
            <span>Non-blocking DB Pool</span>
            <span>•</span>
            <span>V8 Heap Guard</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
