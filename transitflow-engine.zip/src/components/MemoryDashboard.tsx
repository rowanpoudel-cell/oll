import React, { useState } from "react";
import { 
  Cpu, 
  Trash2, 
  Flame, 
  CheckCircle2, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Layers, 
  Gauge, 
  Zap 
} from "lucide-react";
import { MemoryStats } from "../types.ts";

interface MemoryDashboardProps {
  memStats: MemoryStats | null;
  onRefresh: () => void;
}

export const MemoryDashboard: React.FC<MemoryDashboardProps> = ({ memStats, onRefresh }) => {
  const [gcLoading, setGcLoading] = useState(false);
  const [gcMessage, setGcMessage] = useState<string | null>(null);
  const [stressMb, setStressMb] = useState<number>(15);
  const [retainMemory, setRetainMemory] = useState<boolean>(false);
  const [stressLoading, setStressLoading] = useState(false);
  const [stressMessage, setStressMessage] = useState<string | null>(null);

  const handleTriggerGc = async () => {
    setGcLoading(true);
    setGcMessage(null);
    try {
      const res = await fetch("/api/system/gc", { method: "POST" });
      const data = await res.json();
      setGcMessage(data.message || "Garbage collection completed.");
      onRefresh();
    } catch (err: any) {
      setGcMessage(`Failed: ${err.message}`);
    } finally {
      setGcLoading(false);
    }
  };

  const handleRunStressTest = async () => {
    setStressLoading(true);
    setStressMessage(null);
    try {
      const res = await fetch("/api/system/stress-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ megabytes: stressMb, retain: retainMemory }),
      });
      const data = await res.json();
      setStressMessage(data.message || `Allocated ${stressMb} MB successfully.`);
      onRefresh();
    } catch (err: any) {
      setStressMessage(`Stress test error: ${err.message}`);
    } finally {
      setStressLoading(false);
    }
  };

  const handleClearRetainedMemory = async () => {
    setStressLoading(true);
    try {
      const res = await fetch("/api/system/clear-stress", { method: "POST" });
      const data = await res.json();
      setStressMessage(data.message || "Cleared simulated memory.");
      onRefresh();
    } catch (err: any) {
      setStressMessage(`Clear error: ${err.message}`);
    } finally {
      setStressLoading(false);
    }
  };

  if (!memStats) {
    return (
      <div className="p-8 text-center bg-[#111114] rounded-xl border border-[#222226] shadow-xs">
        <Cpu className="w-8 h-8 mx-auto text-[#9CA3AF] animate-spin mb-2" />
        <p className="text-sm text-[#9CA3AF]">Loading live memory diagnostics...</p>
      </div>
    );
  }

  const getStatusColor = (status: MemoryStats["status"]) => {
    switch (status) {
      case "critical":
        return "text-rose-400 bg-rose-950/50 border-rose-800/50";
      case "high":
        return "text-amber-400 bg-amber-950/50 border-amber-800/50";
      case "moderate":
        return "text-blue-400 bg-blue-950/50 border-blue-800/50";
      default:
        return "text-emerald-400 bg-emerald-950/50 border-emerald-800/50";
    }
  };

  return (
    <div className="space-y-6">
      {/* Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Heap Used Card */}
        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>HEAP USED</span>
            <Cpu className="w-4 h-4 text-blue-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#F3F4F6]">{memStats.heapUsedMb}</span>
            <span className="text-xs text-[#9CA3AF] font-medium">MB</span>
          </div>
          <div className="mt-3 w-full bg-[#1A1A1E] rounded-full h-2 overflow-hidden border border-[#222226]">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                memStats.heapUsedPercent > 75
                  ? "bg-rose-500"
                  : memStats.heapUsedPercent > 50
                  ? "bg-amber-500"
                  : "bg-blue-500"
              }`}
              style={{ width: `${Math.min(100, Math.max(5, memStats.heapUsedPercent))}%` }}
            />
          </div>
          <div className="flex justify-between text-[11px] text-[#9CA3AF] mt-1.5">
            <span>{memStats.heapUsedPercent}% of heap</span>
            <span>Limit: {memStats.heapLimitMb} MB</span>
          </div>
        </div>

        {/* Resident Set Size (RSS) */}
        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>TOTAL PROCESS RSS</span>
            <Layers className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#F3F4F6]">{memStats.rssMb}</span>
            <span className="text-xs text-[#9CA3AF] font-medium">MB</span>
          </div>
          <p className="text-xs text-[#9CA3AF] mt-3">
            Total RAM allocated including C++ bindings, V8 heap & buffers.
          </p>
        </div>

        {/* Memory Health Status */}
        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>HEALTH STATUS</span>
            <Gauge className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex items-center gap-2">
            <span
              className={`px-2.5 py-1 rounded-md text-xs font-semibold uppercase tracking-wider border ${getStatusColor(
                memStats.status
              )}`}
            >
              {memStats.status}
            </span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-[#9CA3AF] mt-3">
            {memStats.trend === "increasing" ? (
              <span className="flex items-center text-amber-400 gap-1 font-medium">
                <TrendingUp className="w-3.5 h-3.5" /> Trend: Growing
              </span>
            ) : memStats.trend === "decreasing" ? (
              <span className="flex items-center text-emerald-400 gap-1 font-medium">
                <TrendingDown className="w-3.5 h-3.5" /> Trend: Reclaiming
              </span>
            ) : (
              <span className="flex items-center text-[#9CA3AF] gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Trend: Stable
              </span>
            )}
          </div>
        </div>

        {/* Bounded LRU Cache */}
        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>BOUNDED LRU CACHE</span>
            <Zap className="w-4 h-4 text-amber-400" />
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-bold text-[#F3F4F6]">{memStats.cacheSize}</span>
            <span className="text-xs text-[#9CA3AF] font-medium">/ {memStats.cacheMaxItems} items</span>
          </div>
          <p className="text-xs text-[#9CA3AF] mt-3">
            Capped capacity with TTL eviction to prevent memory leaks.
          </p>
        </div>
      </div>

      {/* Interactive Memory Management Tools */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Memory Garbage Collector & Bounded Cache Controls */}
        <div className="bg-[#111114] p-6 rounded-xl border border-[#222226] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-[#F3F4F6] flex items-center gap-2">
                <Trash2 className="w-5 h-5 text-blue-400" />
                Active Memory Management & GC
              </h3>
              <span className="text-xs font-medium text-[#9CA3AF]">
                Uptime: {Math.floor(memStats.uptimeSeconds / 60)}m {memStats.uptimeSeconds % 60}s
              </span>
            </div>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-4">
              TransitFlow utilizes automatic cache eviction, buffer pooling, and memory leak guards.
              You can trigger active cache purging and memory reclamation at any time.
            </p>

            <div className="bg-[#1A1A1E] p-4 rounded-lg border border-[#2E2E35] mb-4 space-y-2 text-xs text-[#E2E2E2]">
              <div className="flex justify-between">
                <span className="text-[#9CA3AF]">Heap Total:</span>
                <span className="font-mono">{memStats.heapTotalMb} MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#9CA3AF]">External C++ Memory:</span>
                <span className="font-mono">{memStats.externalMb} MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#9CA3AF]">ArrayBuffers:</span>
                <span className="font-mono">{memStats.arrayBuffersMb} MB</span>
              </div>
              <div className="flex justify-between">
                <span className="text-[#9CA3AF]">Simulated Retained Chunks:</span>
                <span className="font-semibold font-mono text-indigo-400">{memStats.allocationsSimulated} MB</span>
              </div>
            </div>

            {gcMessage && (
              <div className="p-3 mb-4 rounded-lg bg-emerald-950/50 border border-emerald-800/50 text-emerald-300 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0 text-emerald-400" />
                <span>{gcMessage}</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-3 pt-2">
            <button
              id="trigger-gc-btn"
              onClick={handleTriggerGc}
              disabled={gcLoading}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-[#1A1A1E] hover:bg-[#222226] text-white border border-[#2E2E35] rounded-lg text-sm font-medium transition-colors disabled:opacity-50 shadow-xs"
            >
              <Trash2 className={`w-4 h-4 text-blue-400 ${gcLoading ? "animate-spin" : ""}`} />
              {gcLoading ? "Purging Memory..." : "Purge Caches & Trigger GC"}
            </button>
          </div>
        </div>

        {/* Memory Stress Test & Leak Simulator */}
        <div className="bg-[#111114] p-6 rounded-xl border border-[#222226] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-semibold text-[#F3F4F6] flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" />
                Stress Test & Resilience Validator
              </h3>
              <span className="text-xs font-semibold px-2 py-0.5 rounded bg-amber-950/60 text-amber-400 border border-amber-800/50">
                Safe Simulator
              </span>
            </div>
            <p className="text-sm text-[#9CA3AF] leading-relaxed mb-4">
              Allocate memory chunks to observe how the V8 engine and heap limits behave without
              crashing the Node.js process.
            </p>

            <div className="space-y-4 mb-4">
              <div>
                <label className="block text-xs font-medium text-[#9CA3AF] mb-1.5">
                  Buffer Allocation Size: <span className="font-bold text-[#F3F4F6] font-mono">{stressMb} MB</span>
                </label>
                <input
                  id="stress-mb-slider"
                  type="range"
                  min="5"
                  max="50"
                  step="5"
                  value={stressMb}
                  onChange={(e) => setStressMb(Number(e.target.value))}
                  className="w-full h-2 bg-[#222226] rounded-lg appearance-none cursor-pointer accent-blue-500 border border-[#2E2E35]"
                />
                <div className="flex justify-between text-[11px] text-[#6B7280] mt-1.5">
                  <span>5 MB</span>
                  <span>25 MB</span>
                  <span>50 MB (Capped)</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <input
                  id="retain-memory-toggle"
                  type="checkbox"
                  checked={retainMemory}
                  onChange={(e) => setRetainMemory(e.target.checked)}
                  className="w-4 h-4 rounded bg-[#1A1A1E] border-[#2E2E35] text-blue-600 focus:ring-blue-500 focus:ring-offset-0"
                />
                <label htmlFor="retain-memory-toggle" className="text-xs text-[#E2E2E2] font-medium cursor-pointer">
                  Retain chunks in memory (Simulate memory accumulation)
                </label>
              </div>
            </div>

            {stressMessage && (
              <div className="p-3 mb-4 rounded-lg bg-blue-950/50 border border-blue-800/50 text-blue-300 text-xs flex items-center gap-2">
                <AlertTriangle className="w-4 h-4 shrink-0 text-blue-400" />
                <span>{stressMessage}</span>
              </div>
            )}
          </div>

          <div className="flex items-center gap-2 pt-2">
            <button
              id="run-stress-test-btn"
              onClick={handleRunStressTest}
              disabled={stressLoading}
              className="flex-1 inline-flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-lg text-sm font-medium transition-all disabled:opacity-50 shadow-xs"
            >
              <Flame className={`w-4 h-4 ${stressLoading ? "animate-spin" : ""}`} />
              {stressLoading ? "Allocating..." : `Allocate ${stressMb} MB`}
            </button>

            {memStats.allocationsSimulated > 0 && (
              <button
                id="clear-stress-btn"
                onClick={handleClearRetainedMemory}
                disabled={stressLoading}
                className="px-4 py-2.5 bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 rounded-lg text-sm font-medium transition-colors"
              >
                Clear Chunks
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
