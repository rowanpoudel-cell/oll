import React from "react";
import { Activity, Database, Cpu, ShieldCheck, RefreshCw } from "lucide-react";
import { DatabaseMetrics, MemoryStats } from "../types.ts";

interface HeaderProps {
  activeTab: "memory" | "database" | "transit" | "audit";
  setActiveTab: (tab: "memory" | "database" | "transit" | "audit") => void;
  dbMetrics: DatabaseMetrics | null;
  memStats: MemoryStats | null;
  loading: boolean;
  onRefresh: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  dbMetrics,
  memStats,
  loading,
  onRefresh,
}) => {
  const getDbBadge = () => {
    if (!dbMetrics) return null;
    if (dbMetrics.readyState === 1) {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-950/50 text-emerald-400 border border-emerald-800/50">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          MongoDB: Connected
        </span>
      );
    }
    if (dbMetrics.status === "connecting") {
      return (
        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-950/50 text-amber-400 border border-amber-800/50">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-ping"></span>
          MongoDB: Connecting...
        </span>
      );
    }
    return (
      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-950/50 text-blue-400 border border-blue-800/50">
        <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
        In-Memory Fallback Active
      </span>
    );
  };

  const getMemoryBadge = () => {
    if (!memStats) return null;
    const isHigh = memStats.heapUsedPercent > 70;
    return (
      <span
        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium border ${
          isHigh
            ? "bg-rose-950/50 text-rose-400 border-rose-800/50"
            : "bg-[#1A1A1E] text-[#9CA3AF] border-[#2E2E35]"
        }`}
      >
        <Cpu className="w-3.5 h-3.5" />
        Heap: {memStats.heapUsedMb} MB ({memStats.heapUsedPercent}%)
      </span>
    );
  };

  return (
    <header className="bg-[#111114]/90 backdrop-blur-md border-b border-[#222226] sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo & Brand */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-sm border border-white/10">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-lg font-bold tracking-tight text-[#F3F4F6]">
                  TransitFlow Engine
                </h1>
                <span className="px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-950/60 text-indigo-400 border border-indigo-800/40">
                  v2.0 Resilient
                </span>
              </div>
              <p className="text-xs text-[#9CA3AF]">
                Crash-Proof Startup & Memory Diagnostics
              </p>
            </div>
          </div>

          {/* Quick Metrics & Refresh */}
          <div className="flex items-center gap-2 sm:gap-3">
            <div className="hidden md:flex items-center gap-2">
              {getDbBadge()}
              {getMemoryBadge()}
            </div>

            <button
              id="refresh-telemetry-btn"
              onClick={onRefresh}
              disabled={loading}
              title="Refresh telemetry"
              className="p-2 rounded-lg text-[#9CA3AF] hover:text-[#F3F4F6] hover:bg-[#1A1A1E] transition-colors disabled:opacity-50 border border-transparent hover:border-[#2E2E35]"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex space-x-1 border-t border-[#1A1A1E] py-1 overflow-x-auto">
          <button
            id="tab-memory"
            onClick={() => setActiveTab("memory")}
            className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === "memory"
                ? "bg-[#1A1A1E] text-white border border-[#2E2E35] shadow-xs"
                : "text-[#9CA3AF] hover:text-[#F3F4F6] hover:bg-[#1A1A1E]/60 border border-transparent"
            }`}
          >
            <Cpu className="w-4 h-4 text-blue-400" />
            Memory Diagnostics
          </button>

          <button
            id="tab-database"
            onClick={() => setActiveTab("database")}
            className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === "database"
                ? "bg-[#1A1A1E] text-white border border-[#2E2E35] shadow-xs"
                : "text-[#9CA3AF] hover:text-[#F3F4F6] hover:bg-[#1A1A1E]/60 border border-transparent"
            }`}
          >
            <Database className="w-4 h-4 text-indigo-400" />
            Database & Connection Pool
          </button>

          <button
            id="tab-transit"
            onClick={() => setActiveTab("transit")}
            className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === "transit"
                ? "bg-[#1A1A1E] text-white border border-[#2E2E35] shadow-xs"
                : "text-[#9CA3AF] hover:text-[#F3F4F6] hover:bg-[#1A1A1E]/60 border border-transparent"
            }`}
          >
            <Activity className="w-4 h-4 text-emerald-400" />
            Transit Operations (.lean)
          </button>

          <button
            id="tab-audit"
            onClick={() => setActiveTab("audit")}
            className={`flex items-center gap-2 px-3.5 py-2 text-sm font-medium rounded-lg transition-colors whitespace-nowrap ${
              activeTab === "audit"
                ? "bg-[#1A1A1E] text-white border border-[#2E2E35] shadow-xs"
                : "text-[#9CA3AF] hover:text-[#F3F4F6] hover:bg-[#1A1A1E]/60 border border-transparent"
            }`}
          >
            <ShieldCheck className="w-4 h-4 text-cyan-400" />
            Crash & Performance Audit
          </button>
        </div>
      </div>
    </header>
  );
};
