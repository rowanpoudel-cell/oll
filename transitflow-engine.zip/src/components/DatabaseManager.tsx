import React, { useState } from "react";
import { 
  Database, 
  Link, 
  Unlink, 
  ShieldCheck, 
  CheckCircle2, 
  AlertCircle, 
  Sliders, 
  Info,
  Server
} from "lucide-react";
import { DatabaseMetrics } from "../types.ts";

interface DatabaseManagerProps {
  dbMetrics: DatabaseMetrics | null;
  onRefresh: () => void;
}

export const DatabaseManager: React.FC<DatabaseManagerProps> = ({ dbMetrics, onRefresh }) => {
  const [customUri, setCustomUri] = useState("");
  const [connecting, setConnecting] = useState(false);
  const [actionMessage, setActionMessage] = useState<{ type: "success" | "error" | "info"; text: string } | null>(null);

  const handleConnect = async () => {
    setConnecting(true);
    setActionMessage(null);
    try {
      const res = await fetch("/api/system/database/connect", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ uri: customUri || undefined }),
      });
      const data = await res.json();
      if (data.success) {
        setActionMessage({ type: "success", text: data.message });
      } else {
        setActionMessage({ type: "info", text: data.message });
      }
      onRefresh();
    } catch (err: any) {
      setActionMessage({ type: "error", text: `Connection error: ${err.message}` });
    } finally {
      setConnecting(false);
    }
  };

  const handleDisconnect = async () => {
    setConnecting(true);
    setActionMessage(null);
    try {
      const res = await fetch("/api/system/database/disconnect", { method: "POST" });
      const data = await res.json();
      setActionMessage({ type: "info", text: data.message });
      onRefresh();
    } catch (err: any) {
      setActionMessage({ type: "error", text: `Disconnect error: ${err.message}` });
    } finally {
      setConnecting(false);
    }
  };

  if (!dbMetrics) {
    return (
      <div className="p-8 text-center bg-[#111114] rounded-xl border border-[#222226] shadow-xs">
        <Database className="w-8 h-8 mx-auto text-[#9CA3AF] animate-spin mb-2" />
        <p className="text-sm text-[#9CA3AF]">Loading database status...</p>
      </div>
    );
  }

  const isConnected = dbMetrics.readyState === 1;

  return (
    <div className="space-y-6">
      {/* Status Banner */}
      <div className={`p-6 rounded-xl border ${
        isConnected 
          ? "bg-emerald-950/30 border-emerald-800/40" 
          : "bg-blue-950/30 border-blue-800/40"
      }`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-start gap-4">
            <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 ${
              isConnected ? "bg-emerald-600 text-white" : "bg-blue-600 text-white"
            }`}>
              <Database className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-lg font-bold text-[#F3F4F6]">
                  {isConnected ? "MongoDB Connected" : "In-Memory Resilient Engine Active"}
                </h3>
                <span className={`px-2 py-0.5 rounded text-xs font-semibold uppercase ${
                  isConnected 
                    ? "bg-emerald-950/70 text-emerald-400 border border-emerald-800/50" 
                    : "bg-blue-950/70 text-blue-400 border border-blue-800/50"
                }`}>
                  {dbMetrics.mode}
                </span>
              </div>
              <p className="text-sm text-[#9CA3AF] mt-1">
                {isConnected
                  ? `Connected URI: ${dbMetrics.maskedUri}`
                  : "Zero-crash architecture: TransitFlow handles requests with zero downtime even without an external database."}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {isConnected ? (
              <button
                id="disconnect-db-btn"
                onClick={handleDisconnect}
                disabled={connecting}
                className="inline-flex items-center gap-2 px-4 py-2 bg-rose-950/50 hover:bg-rose-900/60 text-rose-300 border border-rose-800/50 rounded-lg text-sm font-medium transition-colors"
              >
                <Unlink className="w-4 h-4" />
                Disconnect
              </button>
            ) : (
              <button
                id="reconnect-db-btn"
                onClick={handleConnect}
                disabled={connecting}
                className="inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-500 hover:to-indigo-500 text-white rounded-lg text-sm font-medium transition-all shadow-xs"
              >
                <Link className="w-4 h-4" />
                {connecting ? "Testing Connection..." : "Test / Connect Database"}
              </button>
            )}
          </div>
        </div>
      </div>

      {actionMessage && (
        <div className={`p-4 rounded-xl border text-sm flex items-center gap-3 ${
          actionMessage.type === "success"
            ? "bg-emerald-950/50 border-emerald-800/50 text-emerald-300"
            : actionMessage.type === "error"
            ? "bg-rose-950/50 border-rose-800/50 text-rose-300"
            : "bg-blue-950/50 border-blue-800/50 text-blue-300"
        }`}>
          {actionMessage.type === "success" ? (
            <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-400" />
          ) : actionMessage.type === "error" ? (
            <AlertCircle className="w-5 h-5 shrink-0 text-rose-400" />
          ) : (
            <Info className="w-5 h-5 shrink-0 text-blue-400" />
          )}
          <span>{actionMessage.text}</span>
        </div>
      )}

      {/* Connection Pool Specifications */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>MAX POOL SIZE</span>
            <Sliders className="w-4 h-4 text-blue-400" />
          </div>
          <div className="text-2xl font-bold text-[#F3F4F6]">{dbMetrics.maxPoolSize} sockets</div>
          <p className="text-xs text-[#9CA3AF] mt-2">
            Prevents thread exhaustion and file descriptor leaks under high request spikes.
          </p>
        </div>

        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>MIN POOL SIZE</span>
            <Server className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="text-2xl font-bold text-[#F3F4F6]">{dbMetrics.minPoolSize} warm sockets</div>
          <p className="text-xs text-[#9CA3AF] mt-2">
            Pre-allocated connection pool avoids connection overhead latency for initial queries.
          </p>
        </div>

        <div className="bg-[#111114] p-5 rounded-xl border border-[#222226] shadow-xs">
          <div className="flex items-center justify-between text-[#9CA3AF] text-xs font-medium mb-2">
            <span>IDLE RECLAMATION</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="text-2xl font-bold text-[#F3F4F6]">30,000 ms</div>
          <p className="text-xs text-[#9CA3AF] mt-2">
            Automatically closes unused sockets after 30 seconds to reclaim memory buffers.
          </p>
        </div>
      </div>

      {/* Connection Configurator */}
      <div className="bg-[#111114] p-6 rounded-xl border border-[#222226] shadow-xs">
        <h3 className="text-base font-semibold text-[#F3F4F6] mb-2">
          MongoDB Connection Tester
        </h3>
        <p className="text-sm text-[#9CA3AF] mb-4">
          You can test connecting to a MongoDB Atlas cluster or local URI at any time. If the target is unreachable, TransitFlow will not crash — it will safely report the diagnostic error and remain fully operational.
        </p>

        <div className="flex flex-col sm:flex-row gap-3">
          <input
            id="mongodb-uri-input"
            type="text"
            placeholder="mongodb+srv://user:pass@cluster.mongodb.net/transitflow"
            value={customUri}
            onChange={(e) => setCustomUri(e.target.value)}
            className="flex-1 px-3.5 py-2 bg-[#1A1A1E] border border-[#2E2E35] rounded-lg text-sm text-[#E2E2E2] placeholder:text-[#6B7280] focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
          <button
            id="connect-custom-uri-btn"
            onClick={handleConnect}
            disabled={connecting}
            className="px-5 py-2 bg-[#1A1A1E] hover:bg-[#222226] text-white border border-[#2E2E35] rounded-lg text-sm font-medium transition-colors disabled:opacity-50 shadow-xs shrink-0"
          >
            {connecting ? "Connecting..." : "Test / Update Connection"}
          </button>
        </div>

        {dbMetrics.lastError && (
          <div className="mt-4 p-3 bg-amber-950/50 border border-amber-800/50 rounded-lg text-xs text-amber-300">
            <span className="font-semibold text-amber-400">Last Diagnostics Notice:</span> {dbMetrics.lastError}
          </div>
        )}
      </div>
    </div>
  );
};
