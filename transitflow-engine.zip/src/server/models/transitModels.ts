import mongoose, { Schema, Document } from "mongoose";

export interface IRoute extends Document {
  routeId: string;
  name: string;
  type: "bus" | "subway" | "tram" | "ferry";
  stopsCount: number;
  frequencyMinutes: number;
  status: "active" | "delayed" | "maintenance";
  color: string;
  createdAt: Date;
  updatedAt: Date;
}

const RouteSchema = new Schema<IRoute>(
  {
    routeId: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true, index: true },
    type: { type: String, required: true, enum: ["bus", "subway", "tram", "ferry"], index: true },
    stopsCount: { type: Number, required: true, min: 2 },
    frequencyMinutes: { type: Number, required: true, default: 10 },
    status: { type: String, required: true, enum: ["active", "delayed", "maintenance"], default: "active" },
    color: { type: String, default: "#3B82F6" },
  },
  {
    timestamps: true,
    // Optimizes memory by avoiding excess overhead
    toJSON: { virtuals: false },
    toObject: { virtuals: false },
  }
);

// Compound index for efficient filtered queries
RouteSchema.index({ type: 1, status: 1 });

export const Route = mongoose.models.Route || mongoose.model<IRoute>("Route", RouteSchema);

export interface IVehicle extends Document {
  vehicleId: string;
  routeId: string;
  driverName: string;
  passengerOccupancy: number; // 0 - 100%
  speedKmh: number;
  fuelOrBattery: number; // 0 - 100%
  status: "in_transit" | "stopped" | "idle" | "out_of_service";
  latitude: number;
  longitude: number;
  lastPingAt: Date;
}

const VehicleSchema = new Schema<IVehicle>(
  {
    vehicleId: { type: String, required: true, unique: true, index: true },
    routeId: { type: String, required: true, index: true },
    driverName: { type: String, required: true },
    passengerOccupancy: { type: Number, default: 0, min: 0, max: 100 },
    speedKmh: { type: Number, default: 0, min: 0, max: 150 },
    fuelOrBattery: { type: Number, default: 100, min: 0, max: 100 },
    status: { type: String, enum: ["in_transit", "stopped", "idle", "out_of_service"], default: "in_transit", index: true },
    latitude: { type: Number, required: true },
    longitude: { type: Number, required: true },
    lastPingAt: { type: Date, default: Date.now, index: true },
  },
  {
    timestamps: true,
  }
);

export const Vehicle = mongoose.models.Vehicle || mongoose.model<IVehicle>("Vehicle", VehicleSchema);

// Initial in-memory mock dataset for resilient fallback when MongoDB is unconfigured
export const inMemoryData = {
  routes: [
    {
      _id: "r1",
      routeId: "R-101",
      name: "Downtown Express",
      type: "subway" as const,
      stopsCount: 14,
      frequencyMinutes: 4,
      status: "active" as const,
      color: "#3B82F6",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      _id: "r2",
      routeId: "R-204",
      name: "Uptown River Loop",
      type: "tram" as const,
      stopsCount: 22,
      frequencyMinutes: 8,
      status: "active" as const,
      color: "#10B981",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      _id: "r3",
      routeId: "R-309",
      name: "Airport Shuttle Express",
      type: "bus" as const,
      stopsCount: 6,
      frequencyMinutes: 15,
      status: "delayed" as const,
      color: "#F59E0B",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      _id: "r4",
      routeId: "R-412",
      name: "Harbor Ferry Line",
      type: "ferry" as const,
      stopsCount: 5,
      frequencyMinutes: 20,
      status: "active" as const,
      color: "#06B6D4",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
    {
      _id: "r5",
      routeId: "R-520",
      name: "Tech Corridor Rapid",
      type: "bus" as const,
      stopsCount: 18,
      frequencyMinutes: 6,
      status: "maintenance" as const,
      color: "#8B5CF6",
      createdAt: new Date(),
      updatedAt: new Date(),
    },
  ],
  vehicles: [
    {
      _id: "v1",
      vehicleId: "BUS-881",
      routeId: "R-309",
      driverName: "Alex Mercer",
      passengerOccupancy: 74,
      speedKmh: 42,
      fuelOrBattery: 86,
      status: "in_transit" as const,
      latitude: 37.7749,
      longitude: -122.4194,
      lastPingAt: new Date(),
    },
    {
      _id: "v2",
      vehicleId: "SUB-102",
      routeId: "R-101",
      driverName: "Sarah Chen",
      passengerOccupancy: 89,
      speedKmh: 68,
      fuelOrBattery: 95,
      status: "in_transit" as const,
      latitude: 37.7833,
      longitude: -122.4167,
      lastPingAt: new Date(),
    },
    {
      _id: "v3",
      vehicleId: "TRM-403",
      routeId: "R-204",
      driverName: "Marcus Vance",
      passengerOccupancy: 35,
      speedKmh: 28,
      fuelOrBattery: 62,
      status: "in_transit" as const,
      latitude: 37.7651,
      longitude: -122.4312,
      lastPingAt: new Date(),
    },
    {
      _id: "v4",
      vehicleId: "FRY-011",
      routeId: "R-412",
      driverName: "Elena Rostova",
      passengerOccupancy: 48,
      speedKmh: 22,
      fuelOrBattery: 78,
      status: "stopped" as const,
      latitude: 37.7955,
      longitude: -122.3937,
      lastPingAt: new Date(),
    },
  ],
};
