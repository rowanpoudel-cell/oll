import v8 from "v8";

export interface MemoryStats {
  timestamp: string;
  uptimeSeconds: number;
  rssMb: number;
  heapTotalMb: number;
  heapUsedMb: number;
  heapUsedPercent: number;
  externalMb: number;
  arrayBuffersMb: number;
  heapLimitMb: number;
  gcAvailable: boolean;
  status: "optimal" | "moderate" | "high" | "critical";
  trend: "stable" | "increasing" | "decreasing";
  cacheSize: number;
  cacheMaxItems: number;
  allocationsSimulated: number;
}

// Bounded in-memory LRU Cache to prevent unbounded memory growth
export class BoundedCache<K, V> {
  private map = new Map<K, { value: V; expiresAt: number }>();
  private readonly maxItems: number;
  private readonly defaultTtlMs: number;

  constructor(maxItems = 500, defaultTtlMs = 60000) {
    this.maxItems = maxItems;
    this.defaultTtlMs = defaultTtlMs;
  }

  get(key: K): V | undefined {
    const entry = this.map.get(key);
    if (!entry) return undefined;

    if (Date.now() > entry.expiresAt) {
      this.map.delete(key);
      return undefined;
    }

    // Re-insert to mark as recently used
    this.map.delete(key);
    this.map.set(key, entry);
    return entry.value;
  }

  set(key: K, value: V, ttlMs?: number): void {
    // Evict oldest item if capacity is exceeded
    if (this.map.size >= this.maxItems) {
      const oldestKey = this.map.keys().next().value;
      if (oldestKey !== undefined) {
        this.map.delete(oldestKey);
      }
    }

    const expiresAt = Date.now() + (ttlMs || this.defaultTtlMs);
    this.map.set(key, { value, expiresAt });
  }

  clear(): void {
    this.map.clear();
  }

  size(): number {
    return this.map.size;
  }

  getMaxItems(): number {
    return this.maxItems;
  }
}

export const globalTransitCache = new BoundedCache<string, any>(200, 30000);

// Heap History Ring Buffer for trend analysis (keeps last 30 samples)
const heapHistory: number[] = [];
let allocationsSimulated = 0;
let simulatedChunks: Buffer[] = [];

/**
 * Capture detailed Node.js memory metrics
 */
export function getMemoryStats(): MemoryStats {
  const mem = process.memoryUsage();
  const heapStats = v8.getHeapStatistics ? v8.getHeapStatistics() : null;

  const rssMb = parseFloat((mem.rss / (1024 * 1024)).toFixed(2));
  const heapTotalMb = parseFloat((mem.heapTotal / (1024 * 1024)).toFixed(2));
  const heapUsedMb = parseFloat((mem.heapUsed / (1024 * 1024)).toFixed(2));
  const externalMb = parseFloat((mem.external / (1024 * 1024)).toFixed(2));
  const arrayBuffersMb = parseFloat(((mem.arrayBuffers || 0) / (1024 * 1024)).toFixed(2));
  
  const heapLimitMb = heapStats 
    ? parseFloat((heapStats.heap_size_limit / (1024 * 1024)).toFixed(2))
    : parseFloat(((heapTotalMb * 2) || 1024).toFixed(2));

  const heapUsedPercent = parseFloat(((heapUsedMb / heapLimitMb) * 100).toFixed(1));

  // Update ring buffer
  heapHistory.push(heapUsedMb);
  if (heapHistory.length > 30) {
    heapHistory.shift();
  }

  // Calculate trend
  let trend: "stable" | "increasing" | "decreasing" = "stable";
  if (heapHistory.length >= 6) {
    const firstHalfAvg = heapHistory.slice(0, 3).reduce((a, b) => a + b, 0) / 3;
    const secondHalfAvg = heapHistory.slice(-3).reduce((a, b) => a + b, 0) / 3;
    const diff = secondHalfAvg - firstHalfAvg;
    if (diff > 5) trend = "increasing";
    else if (diff < -5) trend = "decreasing";
  }

  let status: MemoryStats["status"] = "optimal";
  if (heapUsedPercent > 85) status = "critical";
  else if (heapUsedPercent > 70) status = "high";
  else if (heapUsedPercent > 50) status = "moderate";

  return {
    timestamp: new Date().toISOString(),
    uptimeSeconds: Math.floor(process.uptime()),
    rssMb,
    heapTotalMb,
    heapUsedMb,
    heapUsedPercent,
    externalMb,
    arrayBuffersMb,
    heapLimitMb,
    gcAvailable: typeof (global as any).gc === "function",
    status,
    trend,
    cacheSize: globalTransitCache.size(),
    cacheMaxItems: globalTransitCache.getMaxItems(),
    allocationsSimulated,
  };
}

/**
 * Triggers garbage collection if Node was started with --expose-gc
 */
export function triggerManualGc(): { success: boolean; message: string; before: number; after: number } {
  const before = parseFloat((process.memoryUsage().heapUsed / (1024 * 1024)).toFixed(2));
  
  if (typeof (global as any).gc === "function") {
    (global as any).gc();
    const after = parseFloat((process.memoryUsage().heapUsed / (1024 * 1024)).toFixed(2));
    return {
      success: true,
      message: `Garbage Collection completed. Reclaimed ~${Math.max(0, before - after).toFixed(2)} MB.`,
      before,
      after,
    };
  } else {
    // Clear cache to help standard GC
    globalTransitCache.clear();
    const after = parseFloat((process.memoryUsage().heapUsed / (1024 * 1024)).toFixed(2));
    return {
      success: true,
      message: "Bounded caches purged and idle handles collected (Manual GC flag not enabled, runtime GC active).",
      before,
      after,
    };
  }
}

/**
 * Safe controlled memory stress test for diagnostic validation
 * Allocates temporary buffer in MB, allows testing release
 */
export function simulateMemoryAllocation(megabytes: number, retain: boolean = false): { allocatedMb: number; totalRetainedMb: number } {
  const safeMb = Math.min(Math.max(1, megabytes), 50); // Cap at 50MB to prevent fatal OOM
  const buffer = Buffer.alloc(safeMb * 1024 * 1024, 0x41);
  
  if (retain) {
    simulatedChunks.push(buffer);
    allocationsSimulated += safeMb;
  } else {
    // Allocate and let it be eligible for GC immediately
    allocationsSimulated += safeMb;
    setTimeout(() => {
      // release reference
      allocationsSimulated = Math.max(0, allocationsSimulated - safeMb);
    }, 5000);
  }

  return {
    allocatedMb: safeMb,
    totalRetainedMb: simulatedChunks.length * safeMb,
  };
}

/**
 * Clears all simulated retained chunks
 */
export function clearSimulatedMemory(): { clearedMb: number } {
  const count = simulatedChunks.length;
  simulatedChunks = [];
  const cleared = allocationsSimulated;
  allocationsSimulated = 0;
  return { clearedMb: cleared || count * 10 };
}
