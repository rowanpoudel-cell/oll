import mongoose from "mongoose";

export interface DatabaseMetrics {
  status: "connected" | "connecting" | "disconnected" | "error" | "unconfigured";
  uriConfigured: boolean;
  maskedUri: string;
  readyState: number;
  activeConnections: number;
  totalConnectionsCreated: number;
  maxPoolSize: number;
  minPoolSize: number;
  reconnectAttempts: number;
  lastConnectedAt: string | null;
  lastError: string | null;
  mode: "database" | "in-memory-fallback";
}

let reconnectTimeout: NodeJS.Timeout | null = null;
let reconnectAttempts = 0;
const MAX_RETRY_ATTEMPTS = 5;
let lastConnectedAt: string | null = null;
let lastError: string | null = null;
let totalConnectionsCreated = 0;

/**
 * Masks sensitive credentials in MongoDB connection string
 */
export function maskUri(uri?: string): string {
  if (!uri) return "None (In-Memory Fallback Active)";
  try {
    return uri.replace(/\/\/([^:]+):([^@]+)@/, "//***:***@");
  } catch {
    return "mongodb://***";
  }
}

/**
 * Optimized MongoDB Connection Pool Settings to avoid memory exhaustion
 * and connection leaks.
 */
export function getConnectionOptions() {
  const maxPoolSize = parseInt(process.env.MONGO_MAX_POOL_SIZE || "20", 10);
  const minPoolSize = parseInt(process.env.MONGO_MIN_POOL_SIZE || "2", 10);
  const maxIdleTimeMS = parseInt(process.env.MONGO_MAX_IDLE_TIME_MS || "30000", 10);

  return {
    maxPoolSize, // Prevents socket explosion & file descriptor leaks
    minPoolSize, // Keeps minimal warm connections in memory
    maxIdleTimeMS, // Frees idle connection sockets after 30s
    serverSelectionTimeoutMS: 5000, // Fails fast in 5s instead of hanging requests in memory
    socketTimeoutMS: 45000, // Closes dead sockets
    autoIndex: process.env.NODE_ENV !== "production", // Disables auto-indexing in production to prevent RAM spikes
    bufferCommands: false, // Prevents unbounded queue buildup in memory when disconnected
  };
}

/**
 * Resilient Database Connector
 * 
 * CRITICAL FIX:
 * 1. Non-blocking: Never calls process.exit(1) on failure.
 * 2. Graceful Degradation: Works seamlessly in in-memory mode if MONGODB_URI is missing.
 * 3. Exponential Backoff: Handles transient network cuts without infinite crash loops.
 */
export async function connectDatabase(customUri?: string): Promise<boolean> {
  const uri = customUri || process.env.MONGODB_URI;

  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }

  if (!uri || uri.trim() === "" || uri.includes("MY_MONGODB_URI")) {
    console.warn("⚠️ [TransitFlow DB] No valid MONGODB_URI provided. Initializing in resilient IN-MEMORY FALLBACK mode.");
    lastError = "MONGODB_URI not configured. Operating in high-performance memory fallback mode.";
    return false;
  }

  // If already connected, do not re-connect
  if (mongoose.connection.readyState === 1) {
    console.log("ℹ️ [TransitFlow DB] MongoDB is already connected.");
    return true;
  }

  try {
    console.log(`🔌 [TransitFlow DB] Attempting connection to: ${maskUri(uri)}...`);
    const options = getConnectionOptions();

    // Attach listeners once
    setupMongooseListeners();

    await mongoose.connect(uri, options);
    lastConnectedAt = new Date().toISOString();
    lastError = null;
    reconnectAttempts = 0;
    totalConnectionsCreated++;
    console.log("✅ [TransitFlow DB] MongoDB connected successfully with optimized pool settings.");
    return true;
  } catch (error: any) {
    const errorMsg = error?.message || "Unknown database connection error";
    lastError = errorMsg;
    console.error(`❌ [TransitFlow DB] Database connection failed: ${errorMsg}`);
    
    // Schedule background retry with exponential backoff if below threshold
    scheduleReconnect(uri);
    return false;
  }
}

function scheduleReconnect(uri: string) {
  if (reconnectAttempts >= MAX_RETRY_ATTEMPTS) {
    console.warn(`⚠️ [TransitFlow DB] Reached maximum reconnection attempts (${MAX_RETRY_ATTEMPTS}). Retaining in-memory fallback.`);
    return;
  }

  reconnectAttempts++;
  const delay = Math.min(1000 * Math.pow(2, reconnectAttempts), 30000);
  console.log(`🔄 [TransitFlow DB] Scheduling reconnection attempt #${reconnectAttempts} in ${delay / 1000}s...`);

  reconnectTimeout = setTimeout(async () => {
    try {
      await connectDatabase(uri);
    } catch {
      // Handled inside connectDatabase
    }
  }, delay);
}

let listenersConfigured = false;
function setupMongooseListeners() {
  if (listenersConfigured) return;
  listenersConfigured = true;

  mongoose.connection.on("connected", () => {
    console.log("🟢 [TransitFlow DB Event] MongoDB connection established.");
  });

  mongoose.connection.on("error", (err) => {
    lastError = err?.message || "Connection runtime error";
    console.error("🔴 [TransitFlow DB Event] MongoDB error:", lastError);
  });

  mongoose.connection.on("disconnected", () => {
    console.warn("🟡 [TransitFlow DB Event] MongoDB disconnected.");
  });
}

/**
 * Returns current database status & pool telemetry
 */
export function getDatabaseMetrics(): DatabaseMetrics {
  const uri = process.env.MONGODB_URI;
  const readyState = mongoose.connection.readyState;

  let status: DatabaseMetrics["status"] = "disconnected";
  if (!uri) {
    status = "unconfigured";
  } else if (readyState === 1) {
    status = "connected";
  } else if (readyState === 2) {
    status = "connecting";
  } else if (lastError) {
    status = "error";
  }

  const options = getConnectionOptions();

  return {
    status,
    uriConfigured: Boolean(uri && uri.trim().length > 0),
    maskedUri: maskUri(uri),
    readyState,
    activeConnections: readyState === 1 ? 1 : 0,
    totalConnectionsCreated,
    maxPoolSize: options.maxPoolSize,
    minPoolSize: options.minPoolSize,
    reconnectAttempts,
    lastConnectedAt,
    lastError,
    mode: readyState === 1 ? "database" : "in-memory-fallback",
  };
}

/**
 * Clean disconnect for graceful shutdown
 */
export async function closeDatabase(): Promise<void> {
  if (reconnectTimeout) {
    clearTimeout(reconnectTimeout);
    reconnectTimeout = null;
  }

  if (mongoose.connection.readyState !== 0) {
    try {
      await mongoose.disconnect();
      console.log("🛑 [TransitFlow DB] MongoDB connection closed gracefully.");
    } catch (e: any) {
      console.error("Error closing MongoDB connection:", e.message);
    }
  }
}
