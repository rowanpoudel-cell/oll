import { NextResponse } from "next/server";
import { compare } from "bcryptjs";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createSession } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json();
    if (!email || !password) return NextResponse.json({ error: "Email and password are required." }, { status: 400 });
    const [user] = await db.select().from(users).where(eq(users.email, String(email).toLowerCase())).limit(1);
    if (!user || !user.active || !(await compare(String(password), user.passwordHash))) {
      return NextResponse.json({ error: "Invalid email or password." }, { status: 401 });
    }
    const safeUser = { id: user.id, name: user.name, email: user.email, role: user.role };
    await createSession(safeUser);
    return NextResponse.json({ user: safeUser });
  } catch {
    return NextResponse.json({ error: "Unable to sign in right now." }, { status: 500 });
  }
}
