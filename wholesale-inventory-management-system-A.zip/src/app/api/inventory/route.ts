import { NextResponse } from "next/server";
import { db } from "@/db";
import { movements, products, suppliers, users, warehouses } from "@/db/schema";
import { and, desc, eq, ne, sql } from "drizzle-orm";
import { getSession, canManage } from "@/lib/auth";
import { hash } from "bcryptjs";

function error(message: string, status = 400) { return NextResponse.json({ error: message }, { status }); }
function productStatus(stock: number, reorderPoint: number) { return stock <= 0 ? "out_of_stock" as const : stock <= reorderPoint ? "low_stock" as const : "active" as const; }

export async function GET() {
  const user = await getSession();
  if (!user) return error("Unauthorized", 401);
  const [productRows, supplierRows, warehouseRows, movementRows, userRows] = await Promise.all([
    db.select({ id: products.id, name: products.name, sku: products.sku, category: products.category, stock: products.stock, reorderPoint: products.reorderPoint, unitPrice: products.unitPrice, status: products.status, supplierId: products.supplierId, supplier: suppliers.name, warehouseId: products.warehouseId, warehouse: warehouses.name, updatedAt: products.updatedAt }).from(products).leftJoin(suppliers, eq(products.supplierId, suppliers.id)).leftJoin(warehouses, eq(products.warehouseId, warehouses.id)).orderBy(desc(products.updatedAt)),
    db.select().from(suppliers).orderBy(suppliers.name),
    db.select().from(warehouses).orderBy(warehouses.name),
    db.select({ id: movements.id, productId: movements.productId, product: products.name, type: movements.type, quantity: movements.quantity, reference: movements.reference, note: movements.note, createdAt: movements.createdAt, user: users.name }).from(movements).leftJoin(products, eq(movements.productId, products.id)).leftJoin(users, eq(movements.userId, users.id)).orderBy(desc(movements.createdAt)).limit(30),
    user.role === "admin" ? db.select({ id: users.id, name: users.name, email: users.email, role: users.role, active: users.active, createdAt: users.createdAt }).from(users).orderBy(users.name) : Promise.resolve([]),
  ]);
  const totalValue = productRows.reduce((sum, p) => sum + p.stock * Number(p.unitPrice), 0);
  return NextResponse.json({ products: productRows, suppliers: supplierRows, warehouses: warehouseRows, movements: movementRows, users: userRows, stats: { totalProducts: productRows.length, totalUnits: productRows.reduce((s,p)=>s+p.stock,0), lowStock: productRows.filter(p=>p.status !== "active").length, totalValue } });
}

export async function POST(request: Request) {
  const actor = await getSession();
  if (!actor) return error("Unauthorized", 401);
  const body = await request.json();
  const resource = body.resource;
  try {
    if (resource === "movement") {
      const productId = Number(body.productId), quantity = Number(body.quantity);
      if (!productId || !Number.isInteger(quantity) || quantity <= 0 || !["in","out","adjustment"].includes(body.type)) return error("Enter a valid product, type, and quantity.");
      const [product] = await db.select().from(products).where(eq(products.id, productId));
      if (!product) return error("Product not found.", 404);
      const nextStock = body.type === "in" ? product.stock + quantity : body.type === "out" ? product.stock - quantity : quantity;
      if (nextStock < 0) return error("Not enough stock for this movement.");
      await db.transaction(async tx => {
        await tx.insert(movements).values({ productId, userId: actor.id, type: body.type, quantity, reference: body.reference || `MOV-${Date.now()}`, note: body.note || null });
        await tx.update(products).set({ stock: nextStock, status: productStatus(nextStock, product.reorderPoint), updatedAt: new Date() }).where(eq(products.id, productId));
      });
      return NextResponse.json({ ok: true }, { status: 201 });
    }
    if (!canManage(actor.role)) return error("You do not have permission to perform this action.", 403);
    if (resource === "product") {
      const stock = Number(body.stock || 0), reorderPoint = Number(body.reorderPoint || 0);
      if (!body.name || !body.sku || !body.category || Number(body.unitPrice) < 0) return error("Complete all required product fields.");
      const [row] = await db.insert(products).values({ name: body.name, sku: String(body.sku).toUpperCase(), category: body.category, stock, reorderPoint, unitPrice: String(body.unitPrice), supplierId: body.supplierId ? Number(body.supplierId) : null, warehouseId: body.warehouseId ? Number(body.warehouseId) : null, status: productStatus(stock, reorderPoint) }).returning();
      if (stock > 0) await db.insert(movements).values({ productId: row.id, userId: actor.id, type: "in", quantity: stock, reference: "OPENING", note: "Opening balance" });
      return NextResponse.json(row, { status: 201 });
    }
    if (resource === "supplier") {
      if (!body.name || !body.email) return error("Supplier name and email are required.");
      const [row] = await db.insert(suppliers).values({ name: body.name, contact: body.contact || "—", email: body.email, phone: body.phone || "—" }).returning();
      return NextResponse.json(row, { status: 201 });
    }
    if (resource === "user") {
      if (actor.role !== "admin") return error("Only admins can manage users.", 403);
      if (!body.name || !body.email || String(body.password || "").length < 6) return error("Name, email and a 6+ character password are required.");
      const [row] = await db.insert(users).values({ name: body.name, email: String(body.email).toLowerCase(), passwordHash: await hash(body.password, 10), role: body.role || "staff", active: true }).returning({ id: users.id });
      return NextResponse.json(row, { status: 201 });
    }
    return error("Unknown resource.");
  } catch (e) {
    const message = e instanceof Error && e.message.includes("unique") ? "That value already exists." : "Unable to save this record.";
    return error(message);
  }
}

export async function PATCH(request: Request) {
  const actor = await getSession();
  if (!actor) return error("Unauthorized", 401);
  const body = await request.json();
  if (!canManage(actor.role)) return error("You do not have permission.", 403);
  try {
    if (body.resource === "product") {
      const stock = Number(body.stock), reorderPoint = Number(body.reorderPoint);
      await db.update(products).set({ name: body.name, sku: String(body.sku).toUpperCase(), category: body.category, stock, reorderPoint, unitPrice: String(body.unitPrice), supplierId: body.supplierId ? Number(body.supplierId) : null, warehouseId: body.warehouseId ? Number(body.warehouseId) : null, status: productStatus(stock, reorderPoint), updatedAt: new Date() }).where(eq(products.id, Number(body.id)));
    } else if (body.resource === "supplier") {
      await db.update(suppliers).set({ name: body.name, contact: body.contact, email: body.email, phone: body.phone }).where(eq(suppliers.id, Number(body.id)));
    } else if (body.resource === "user" && actor.role === "admin") {
      const id = Number(body.id);
      if (id === actor.id && body.active === false) return error("You cannot deactivate your own account.");
      await db.update(users).set({ name: body.name, email: String(body.email).toLowerCase(), role: body.role, active: Boolean(body.active), ...(body.password ? { passwordHash: await hash(body.password, 10) } : {}) }).where(eq(users.id, id));
    } else return error("Unknown resource or insufficient permission.", 403);
    return NextResponse.json({ ok: true });
  } catch { return error("Unable to update this record."); }
}

export async function DELETE(request: Request) {
  const actor = await getSession();
  if (!actor) return error("Unauthorized", 401);
  if (!canManage(actor.role)) return error("You do not have permission.", 403);
  const { resource, id } = await request.json();
  try {
    if (resource === "product") await db.delete(products).where(eq(products.id, Number(id)));
    else if (resource === "supplier") await db.delete(suppliers).where(eq(suppliers.id, Number(id)));
    else if (resource === "user" && actor.role === "admin") {
      if (Number(id) === actor.id) return error("You cannot delete your own account.");
      await db.delete(users).where(and(eq(users.id, Number(id)), ne(users.id, actor.id)));
    } else return error("Unknown resource or insufficient permission.", 403);
    return NextResponse.json({ ok: true });
  } catch { return error("This record is in use and cannot be deleted."); }
}
