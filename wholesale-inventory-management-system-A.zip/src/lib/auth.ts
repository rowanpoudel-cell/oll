import { cookies } from "next/headers";
import { SignJWT, jwtVerify } from "jose";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";

const secret = new TextEncoder().encode(process.env.AUTH_SECRET || "stockpilot-local-development-secret-change-me");
export type SessionUser = { id: number; name: string; email: string; role: "admin" | "manager" | "staff" };

export async function createSession(user: SessionUser) {
  const token = await new SignJWT(user).setProtectedHeader({ alg: "HS256" }).setIssuedAt().setExpirationTime("7d").sign(secret);
  const jar = await cookies();
  jar.set("stockpilot_session", token, { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", path: "/", maxAge: 60 * 60 * 24 * 7 });
}

export async function clearSession() {
  (await cookies()).set("stockpilot_session", "", { httpOnly: true, path: "/", maxAge: 0 });
}

export async function getSession(): Promise<SessionUser | null> {
  const token = (await cookies()).get("stockpilot_session")?.value;
  if (!token) return null;
  try {
    const { payload } = await jwtVerify(token, secret);
    const id = Number(payload.id);
    const [user] = await db.select().from(users).where(eq(users.id, id)).limit(1);
    if (!user?.active) return null;
    return { id: user.id, name: user.name, email: user.email, role: user.role };
  } catch { return null; }
}

export function canManage(role: SessionUser["role"]) { return role === "admin" || role === "manager"; }
