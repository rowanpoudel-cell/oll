const express = require("express");
const { readDb, writeDb } = require("../utils/db");
const { requireAuth, requireRole } = require("../middleware/auth");

const router = express.Router();

const VALID_STATUSES = ["pending", "confirmed", "in-transit", "delivered", "cancelled"];

// POST /api/orders  - create a new transport order (logged-in user)
router.post("/", requireAuth, (req, res) => {
  const {
    pickupLocation,
    dropLocation,
    cargoType,
    weightKg,
    vehicleType,
    pickupDate,
    notes,
  } = req.body;

  if (!pickupLocation || !dropLocation || !cargoType || !vehicleType || !pickupDate) {
    return res.status(400).json({
      message: "Pickup location, drop location, cargo type, vehicle type and pickup date are required.",
    });
  }

  const db = readDb();
  const newOrder = {
    id: "ord-" + Date.now(),
    userId: req.user.id,
    customerName: req.user.name,
    pickupLocation,
    dropLocation,
    cargoType,
    weightKg: weightKg || null,
    vehicleType,
    pickupDate,
    notes: notes || "",
    status: "pending",
    createdAt: new Date().toISOString(),
  };

  db.orders.unshift(newOrder);
  writeDb(db);

  res.status(201).json({ order: newOrder });
});

// GET /api/orders/mine - orders for the logged-in user
router.get("/mine", requireAuth, (req, res) => {
  const db = readDb();
  const mine = db.orders.filter((o) => o.userId === req.user.id);
  res.json({ orders: mine });
});

// GET /api/orders - all orders (admin only)
router.get("/", requireAuth, requireRole("admin"), (req, res) => {
  const db = readDb();
  res.json({ orders: db.orders });
});

// PATCH /api/orders/:id/status - update status (admin only)
router.patch("/:id/status", requireAuth, requireRole("admin"), (req, res) => {
  const { status } = req.body;
  if (!VALID_STATUSES.includes(status)) {
    return res.status(400).json({ message: `Status must be one of: ${VALID_STATUSES.join(", ")}` });
  }

  const db = readDb();
  const order = db.orders.find((o) => o.id === req.params.id);
  if (!order) return res.status(404).json({ message: "Order not found." });

  order.status = status;
  order.updatedAt = new Date().toISOString();
  writeDb(db);

  res.json({ order });
});

module.exports = router;
