const express = require("express");
const { readDb, writeDb } = require("../utils/db");

const router = express.Router();

// POST /api/contact - public contact form submission
router.post("/", (req, res) => {
  const { name, email, message } = req.body;
  if (!name || !email || !message) {
    return res.status(400).json({ message: "Name, email and message are required." });
  }

  const db = readDb();
  db.messages.unshift({
    id: "msg-" + Date.now(),
    name,
    email,
    message,
    createdAt: new Date().toISOString(),
  });
  writeDb(db);

  res.status(201).json({ message: "Thanks for reaching out - our team will get back to you shortly." });
});

module.exports = router;
