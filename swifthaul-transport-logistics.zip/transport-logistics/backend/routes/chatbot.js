const express = require("express");
const router = express.Router();

// A small rule-based enquiry assistant. No external AI dependency required,
// which keeps this prototype runnable offline. Swap the matchReply()
// function for a real LLM/API call when you're ready to go beyond a demo.

const RULES = [
  {
    keywords: ["track", "tracking", "where is my", "status of order", "order status"],
    reply:
      "You can track any shipment from your Dashboard under 'My Orders' — each order shows a live status (pending, confirmed, in-transit, delivered). If you have an order ID, share it and our support team can look it up manually.",
  },
  {
    keywords: ["price", "cost", "rate", "quote", "how much"],
    reply:
      "Pricing depends on distance, cargo weight and vehicle type. Submit a request from the Order page with your route and cargo details, and we'll send a quote within a few hours.",
  },
  {
    keywords: ["vehicle", "truck", "fleet", "mini truck", "container"],
    reply:
      "Our fleet includes mini trucks, open-body trucks, container trucks and refrigerated vehicles for cold-chain cargo. You can select a vehicle type when placing an order.",
  },
  {
    keywords: ["time", "how long", "delivery time", "eta", "duration"],
    reply:
      "Delivery time depends on the route and vehicle type — most intercity shipments arrive within 24-72 hours. Once your order is confirmed you'll see an estimated delivery date on your dashboard.",
  },
  {
    keywords: ["cancel", "cancellation"],
    reply:
      "Orders can be cancelled from your Dashboard while they're still in 'pending' or 'confirmed' status. Once a shipment is in-transit, please contact support directly to cancel.",
  },
  {
    keywords: ["contact", "phone", "email", "support", "human", "agent"],
    reply:
      "You can reach our support team via the Contact page, or email support@swifthaul.com. We typically respond within one business day.",
  },
  {
    keywords: ["hi", "hello", "hey", "good morning", "good afternoon"],
    reply: "Hello! I'm the SwiftHaul enquiry assistant. Ask me about pricing, tracking, vehicles or delivery times.",
  },
  {
    keywords: ["bye", "thank", "thanks"],
    reply: "You're welcome! Feel free to come back anytime you have a shipping question.",
  },
];

const FALLBACK =
  "I'm not fully sure about that one yet. For pricing, tracking, vehicle types or delivery times just ask directly — or reach our team on the Contact page for anything more specific.";

function matchReply(message) {
  const lower = message.toLowerCase();
  for (const rule of RULES) {
    if (rule.keywords.some((kw) => lower.includes(kw))) {
      return rule.reply;
    }
  }
  return FALLBACK;
}

// POST /api/chatbot  { message: string }
router.post("/", (req, res) => {
  const { message } = req.body;
  if (!message || !message.trim()) {
    return res.status(400).json({ message: "Please include a message." });
  }
  const reply = matchReply(message);
  res.json({ reply });
});

module.exports = router;
