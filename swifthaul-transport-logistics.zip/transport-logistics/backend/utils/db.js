const fs = require("fs");
const path = require("path");
const bcrypt = require("bcryptjs");

const DB_PATH = path.join(__dirname, "..", "data", "db.json");

// This prototype uses a flat JSON file instead of a real database so the
// project runs with zero external setup. Swap this module for a real
// MongoDB / PostgreSQL layer before shipping this to production.

function ensureDb() {
  if (!fs.existsSync(DB_PATH)) {
    const seedAdminPasswordHash = bcrypt.hashSync("Admin@123", 10);
    const seedUserPasswordHash = bcrypt.hashSync("User@123", 10);

    const initial = {
      users: [
        {
          id: "u-admin-1",
          name: "Fleet Admin",
          email: "admin@swifthaul.com",
          password: seedAdminPasswordHash,
          role: "admin",
          createdAt: new Date().toISOString(),
        },
        {
          id: "u-demo-1",
          name: "Demo Customer",
          email: "customer@swifthaul.com",
          password: seedUserPasswordHash,
          role: "user",
          createdAt: new Date().toISOString(),
        },
      ],
      orders: [
        {
          id: "ord-1001",
          userId: "u-demo-1",
          customerName: "Demo Customer",
          pickupLocation: "Kathmandu Depot",
          dropLocation: "Pokhara Warehouse",
          cargoType: "Palletized Goods",
          weightKg: 850,
          vehicleType: "Mini Truck",
          pickupDate: "2026-08-14",
          status: "in-transit",
          notes: "Handle with care - fragile electronics",
          createdAt: new Date().toISOString(),
        },
      ],
      messages: [],
    };
    fs.writeFileSync(DB_PATH, JSON.stringify(initial, null, 2));
  }
}

function readDb() {
  ensureDb();
  const raw = fs.readFileSync(DB_PATH, "utf-8");
  return JSON.parse(raw);
}

function writeDb(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

module.exports = { readDb, writeDb };
