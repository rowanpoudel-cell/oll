import React from "react";

export default function About() {
  return (
    <div className="section">
      <div className="section-head">
        <span className="eyebrow">Who we are</span>
        <h1>A dispatch team that treats every load like it's the only one</h1>
        <p className="lead">
          SwiftHaul is a prototype freight logistics platform connecting shippers with a network of
          trucks and drivers — built to show how booking, tracking and fleet management can live in
          one dashboard.
        </p>
      </div>

      <div className="grid-2">
        <div className="card">
          <h3>Our approach</h3>
          <p className="muted">
            Every order moves through a clear status pipeline — pending, confirmed, in-transit,
            delivered — so shippers always know where a load stands without calling for an update.
          </p>
        </div>
        <div className="card">
          <h3>Built for both sides</h3>
          <p className="muted">
            Customers get a simple booking flow and live order history. Admins get a control panel
            to review every shipment across the fleet and move it through to delivery.
          </p>
        </div>
      </div>

      <div className="section-head" style={{ marginTop: "3rem" }}>
        <span className="eyebrow">Values</span>
        <h2>What we optimise for</h2>
      </div>
      <div className="grid-3">
        <div className="card">
          <h3>Visibility</h3>
          <p className="muted">No black-box shipments — status is always one click away.</p>
        </div>
        <div className="card">
          <h3>Reliability</h3>
          <p className="muted">Right vehicle, right route, on the date you booked.</p>
        </div>
        <div className="card">
          <h3>Simplicity</h3>
          <p className="muted">One form to book, one dashboard to track — nothing extra.</p>
        </div>
      </div>
    </div>
  );
}
