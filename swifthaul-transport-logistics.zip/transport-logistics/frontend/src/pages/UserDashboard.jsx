import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import api from "../api/axios";

const STATUS_LABEL = {
  pending: "Pending",
  confirmed: "Confirmed",
  "in-transit": "In transit",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export default function UserDashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    api
      .get("/orders/mine")
      .then((res) => setOrders(res.data.orders))
      .catch(() => setError("Could not load your orders right now."))
      .finally(() => setLoading(false));
  }, []);

  return (
    <div className="section">
      <div className="section-head">
        <span className="eyebrow">Your account</span>
        <h1>Welcome back, {user?.name?.split(" ")[0]}</h1>
        <p className="lead">Track every load you've booked with SwiftHaul.</p>
      </div>

      <div className="dashboard-toolbar">
        <span className="muted">{orders.length} order{orders.length === 1 ? "" : "s"}</span>
        <Link to="/order" className="btn btn-primary btn-sm">
          Ship a new load
        </Link>
      </div>

      {loading && <p className="muted">Loading your orders…</p>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && !error && orders.length === 0 && (
        <div className="empty-state card">
          <h3>No shipments yet</h3>
          <p className="muted">Once you place an order it will show up here with live status.</p>
          <Link to="/order" className="btn btn-primary">
            Ship your first load
          </Link>
        </div>
      )}

      <div className="orders-list">
        {orders.map((o) => (
          <div className="order-card card" key={o.id}>
            <div className="order-card-head">
              <span className="mono">{o.id}</span>
              <span className={`badge badge-${o.status}`}>{STATUS_LABEL[o.status]}</span>
            </div>
            <div className="order-route">
              <strong>{o.pickupLocation}</strong>
              <span className="route-arrow">→</span>
              <strong>{o.dropLocation}</strong>
            </div>
            <div className="order-meta">
              <span>{o.cargoType}</span>
              <span>·</span>
              <span>{o.vehicleType}</span>
              {o.weightKg && (
                <>
                  <span>·</span>
                  <span>{o.weightKg} kg</span>
                </>
              )}
              <span>·</span>
              <span>Pickup {o.pickupDate}</span>
            </div>
            {o.notes && <p className="muted order-notes">{o.notes}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
