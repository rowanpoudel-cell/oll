import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import api from "../api/axios";

const VEHICLES = ["Mini Truck", "Open-Body Truck", "Container Truck", "Refrigerated Truck", "Express Same-Day"];

const initialForm = {
  pickupLocation: "",
  dropLocation: "",
  cargoType: "",
  weightKg: "",
  vehicleType: VEHICLES[0],
  pickupDate: "",
  notes: "",
};

export default function Order() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState(initialForm);
  const [status, setStatus] = useState({ state: "idle", text: "" });

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!user) {
      navigate("/login", { state: { from: "/order" } });
      return;
    }

    setStatus({ state: "loading", text: "" });
    try {
      await api.post("/orders", { ...form, weightKg: form.weightKg ? Number(form.weightKg) : null });
      setStatus({ state: "success", text: "Order placed. View it anytime from your dashboard." });
      setForm(initialForm);
    } catch (err) {
      setStatus({
        state: "error",
        text: err.response?.data?.message || "Could not place order. Please check the form and try again.",
      });
    }
  }

  return (
    <div className="section">
      <div className="section-head">
        <span className="eyebrow">Book a shipment</span>
        <h1>Ship a load</h1>
        <p className="lead">Fill in the route and cargo details — we'll assign a vehicle and confirm the booking.</p>
      </div>

      {!user && (
        <div className="alert alert-info">
          You'll need to <Link to="/login">log in</Link> or <Link to="/register">create an account</Link> to submit an order.
          You can fill out the form now — we'll take you to login when you submit.
        </div>
      )}

      <form className="card form-card order-form" onSubmit={handleSubmit}>
        <div className="grid-2">
          <label>
            Pickup location
            <input
              type="text"
              required
              value={form.pickupLocation}
              onChange={(e) => update("pickupLocation", e.target.value)}
              placeholder="e.g. Kathmandu Depot"
            />
          </label>
          <label>
            Drop-off location
            <input
              type="text"
              required
              value={form.dropLocation}
              onChange={(e) => update("dropLocation", e.target.value)}
              placeholder="e.g. Pokhara Warehouse"
            />
          </label>
        </div>

        <div className="grid-2">
          <label>
            Cargo type
            <input
              type="text"
              required
              value={form.cargoType}
              onChange={(e) => update("cargoType", e.target.value)}
              placeholder="e.g. Palletized electronics"
            />
          </label>
          <label>
            Weight (kg)
            <input
              type="number"
              min="1"
              value={form.weightKg}
              onChange={(e) => update("weightKg", e.target.value)}
              placeholder="e.g. 850"
            />
          </label>
        </div>

        <div className="grid-2">
          <label>
            Vehicle type
            <select value={form.vehicleType} onChange={(e) => update("vehicleType", e.target.value)}>
              {VEHICLES.map((v) => (
                <option key={v} value={v}>
                  {v}
                </option>
              ))}
            </select>
          </label>
          <label>
            Pickup date
            <input
              type="date"
              required
              value={form.pickupDate}
              onChange={(e) => update("pickupDate", e.target.value)}
            />
          </label>
        </div>

        <label>
          Notes (optional)
          <textarea
            rows={3}
            value={form.notes}
            onChange={(e) => update("notes", e.target.value)}
            placeholder="Handling instructions, contact person at drop-off, etc."
          />
        </label>

        {status.state === "success" && <div className="alert alert-success">{status.text}</div>}
        {status.state === "error" && <div className="alert alert-error">{status.text}</div>}

        <button type="submit" className="btn btn-primary btn-lg" disabled={status.state === "loading"}>
          {status.state === "loading" ? "Placing order…" : "Place order"}
        </button>
      </form>
    </div>
  );
}
