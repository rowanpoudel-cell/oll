import React from "react";
import { Link } from "react-router-dom";

const SERVICES = [
  {
    name: "Mini Truck Delivery",
    desc: "For pallets and small consignments moving within a city or nearby districts.",
    weight: "Up to 1,000 kg",
  },
  {
    name: "Open-Body Truck",
    desc: "General cargo, construction materials and non-fragile bulk goods.",
    weight: "1,000 – 5,000 kg",
  },
  {
    name: "Container Truck",
    desc: "Full container loads for long-haul and inter-district freight.",
    weight: "5,000 – 20,000 kg",
  },
  {
    name: "Refrigerated Transport",
    desc: "Cold-chain vehicles for perishables, produce and temperature-sensitive cargo.",
    weight: "Up to 3,000 kg",
  },
  {
    name: "Express Same-Day",
    desc: "Priority dispatch for urgent, time-critical shipments within city limits.",
    weight: "Up to 500 kg",
  },
  {
    name: "Warehousing & Cross-Dock",
    desc: "Short-term storage and consolidation between two legs of a journey.",
    weight: "Custom",
  },
];

export default function Services() {
  return (
    <div className="section">
      <div className="section-head">
        <span className="eyebrow">What we run</span>
        <h1>Services built around the load, not just the truck</h1>
        <p className="lead">Pick the service that matches your cargo — you can always change vehicle type before dispatch.</p>
      </div>

      <div className="grid-3">
        {SERVICES.map((s) => (
          <div className="card service-card" key={s.name}>
            <h3>{s.name}</h3>
            <p className="muted">{s.desc}</p>
            <span className="badge badge-neutral">{s.weight}</span>
          </div>
        ))}
      </div>

      <div className="cta-band">
        <div>
          <h2>Not sure which service fits?</h2>
          <p className="muted">Tell our enquiry assistant your cargo details, or place an order directly.</p>
        </div>
        <Link to="/order" className="btn btn-primary btn-lg">
          Ship a load
        </Link>
      </div>
    </div>
  );
}
