import React, { useEffect, useMemo, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import api from "../api/axios";

const STATUSES = ["pending", "confirmed", "in-transit", "delivered", "cancelled"];
const STATUS_LABEL = {
  pending: "Pending",
  confirmed: "Confirmed",
  "in-transit": "In transit",
  delivered: "Delivered",
  cancelled: "Cancelled",
};

export default function AdminDashboard() {
  const { user } = useAuth();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState("all");
  const [updatingId, setUpdatingId] = useState(null);

  useEffect(() => {
    loadOrders();
  }, []);

  function loadOrders() {
    setLoading(true);
    api
      .get("/orders")
      .then((res) => setOrders(res.data.orders))
      .catch(() => setError("Could not load orders right now."))
      .finally(() => setLoading(false));
  }

  async function updateStatus(id, status) {
    setUpdatingId(id);
    try {
      const res = await api.patch(`/orders/${id}/status`, { status });
      setOrders((prev) => prev.map((o) => (o.id === id ? res.data.order : o)));
    } catch (err) {
      setError(err.response?.data?.message || "Could not update order status.");
    } finally {
      setUpdatingId(null);
    }
  }

  const counts = useMemo(() => {
    const c = { all: orders.length };
    STATUSES.forEach((s) => (c[s] = orders.filter((o) => o.status === s).length));
    return c;
  }, [orders]);

  const visibleOrders = filter === "all" ? orders : orders.filter((o) => o.status === filter);

  return (
    <div className="section">
      <div className="section-head">
        <span className="eyebrow">Fleet control</span>
        <h1>Admin dashboard</h1>
        <p className="lead">Signed in as {user?.name} — review every shipment and move it through delivery.</p>
      </div>

      <div className="filter-row">
        <button className={`filter-chip ${filter === "all" ? "active" : ""}`} onClick={() => setFilter("all")}>
          All ({counts.all})
        </button>
        {STATUSES.map((s) => (
          <button key={s} className={`filter-chip ${filter === s ? "active" : ""}`} onClick={() => setFilter(s)}>
            {STATUS_LABEL[s]} ({counts[s] || 0})
          </button>
        ))}
      </div>

      {loading && <p className="muted">Loading orders…</p>}
      {error && <div className="alert alert-error">{error}</div>}

      {!loading && visibleOrders.length === 0 && (
        <div className="empty-state card">
          <h3>No orders in this view</h3>
          <p className="muted">Try a different filter.</p>
        </div>
      )}

      <div className="table-wrap">
        {visibleOrders.length > 0 && (
          <table className="admin-table">
            <thead>
              <tr>
                <th>Order</th>
                <th>Customer</th>
                <th>Route</th>
                <th>Vehicle</th>
                <th>Pickup</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {visibleOrders.map((o) => (
                <tr key={o.id}>
                  <td className="mono">{o.id}</td>
                  <td>{o.customerName}</td>
                  <td>
                    {o.pickupLocation} <span className="route-arrow">→</span> {o.dropLocation}
                  </td>
                  <td>{o.vehicleType}</td>
                  <td>{o.pickupDate}</td>
                  <td>
                    <select
                      value={o.status}
                      disabled={updatingId === o.id}
                      onChange={(e) => updateStatus(o.id, e.target.value)}
                      className={`status-select badge-${o.status}`}
                    >
                      {STATUSES.map((s) => (
                        <option key={s} value={s}>
                          {STATUS_LABEL[s]}
                        </option>
                      ))}
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
