import React, { useState } from "react";
import api from "../api/axios";

export default function Contact() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [status, setStatus] = useState({ state: "idle", text: "" });

  function update(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus({ state: "loading", text: "" });
    try {
      const res = await api.post("/contact", form);
      setStatus({ state: "success", text: res.data.message });
      setForm({ name: "", email: "", message: "" });
    } catch (err) {
      setStatus({
        state: "error",
        text: err.response?.data?.message || "Something went wrong. Please try again.",
      });
    }
  }

  return (
    <div className="section">
      <div className="section-head">
        <span className="eyebrow">Get in touch</span>
        <h1>Questions about a shipment or a quote?</h1>
        <p className="lead">Send us a message, or use the enquiry assistant in the bottom-right corner for instant answers.</p>
      </div>

      <div className="grid-2 contact-grid">
        <form className="card form-card" onSubmit={handleSubmit}>
          <label>
            Full name
            <input
              type="text"
              required
              value={form.name}
              onChange={(e) => update("name", e.target.value)}
              placeholder="Your name"
            />
          </label>
          <label>
            Email
            <input
              type="email"
              required
              value={form.email}
              onChange={(e) => update("email", e.target.value)}
              placeholder="you@company.com"
            />
          </label>
          <label>
            Message
            <textarea
              required
              rows={5}
              value={form.message}
              onChange={(e) => update("message", e.target.value)}
              placeholder="Tell us about your shipment or question"
            />
          </label>

          {status.state === "success" && <div className="alert alert-success">{status.text}</div>}
          {status.state === "error" && <div className="alert alert-error">{status.text}</div>}

          <button type="submit" className="btn btn-primary btn-lg" disabled={status.state === "loading"}>
            {status.state === "loading" ? "Sending…" : "Send message"}
          </button>
        </form>

        <div className="card contact-info">
          <h3>Direct lines</h3>
          <p className="muted">support@swifthaul.com</p>
          <p className="muted">+977 1-555-0142</p>
          <h3 style={{ marginTop: "1.5rem" }}>Operating hours</h3>
          <p className="muted">Sunday – Friday, 8:00 AM – 7:00 PM</p>
          <h3 style={{ marginTop: "1.5rem" }}>Depot</h3>
          <p className="muted">Balkhu Logistics Yard, Kathmandu</p>
        </div>
      </div>
    </div>
  );
}
