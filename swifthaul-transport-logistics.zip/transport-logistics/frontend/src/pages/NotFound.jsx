import React from "react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="section not-found">
      <span className="eyebrow">404</span>
      <h1>This route doesn't exist</h1>
      <p className="muted">The page you're looking for may have been moved or never dispatched.</p>
      <Link to="/" className="btn btn-primary">
        Back to home
      </Link>
    </div>
  );
}
