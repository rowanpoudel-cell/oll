import React from "react";
import { Link } from "react-router-dom";

const STOPS = [
  { label: "Pickup", sub: "Depot scan" },
  { label: "In transit", sub: "Live GPS" },
  { label: "Hub transfer", sub: "Cross-dock" },
  { label: "Delivered", sub: "Proof of delivery" },
];

const STATS = [
  { value: "48", label: "Districts served" },
  { value: "1,200+", label: "Loads moved / month" },
  { value: "99.2%", label: "On-time delivery" },
];

export default function Home() {
  return (
    <div>
      <section className="hero">
        <div className="hero-inner">
          <div className="hero-copy">
            <span className="eyebrow">Road freight, planned end to end</span>
            <h1>
              Every shipment,
              <br />
              on a visible route.
            </h1>
            <p className="lead">
              SwiftHaul books, tracks and confirms freight moves across town or across the country —
              from a single mini-truck pallet to a full container load.
            </p>
            <div className="hero-actions">
              <Link to="/order" className="btn btn-primary btn-lg">
                Ship a load
              </Link>
              <Link to="/services" className="btn btn-outline btn-lg">
                See services
              </Link>
            </div>
          </div>

          <div className="hero-visual" aria-hidden="true">
            <div className="route-card">
              <div className="route-card-head">
                <span className="mono">WB-77219</span>
                <span className="badge badge-transit">in-transit</span>
              </div>
              <div className="route-line">
                {STOPS.map((s, i) => (
                  <div className={`route-stop ${i <= 1 ? "done" : ""}`} key={s.label}>
                    <span className="route-dot" />
                    <div className="route-stop-text">
                      <strong>{s.label}</strong>
                      <span>{s.sub}</span>
                    </div>
                  </div>
                ))}
                <div className="route-progress" style={{ height: "38%" }} />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="stats-strip">
        {STATS.map((s) => (
          <div className="stat" key={s.label}>
            <div className="stat-value">{s.value}</div>
            <div className="stat-label">{s.label}</div>
          </div>
        ))}
      </section>

      <section className="section">
        <div className="section-head">
          <span className="eyebrow">How it moves</span>
          <h2>Three steps from booking to delivery</h2>
        </div>
        <div className="grid-3">
          <div className="card">
            <span className="card-index">01</span>
            <h3>Tell us the route</h3>
            <p className="muted">Enter pickup, drop-off, cargo type and weight on the Order page.</p>
          </div>
          <div className="card">
            <span className="card-index">02</span>
            <h3>We assign a vehicle</h3>
            <p className="muted">Our dispatch team matches your load to the right truck and driver.</p>
          </div>
          <div className="card">
            <span className="card-index">03</span>
            <h3>Track to delivery</h3>
            <p className="muted">Watch status update on your dashboard until proof of delivery lands.</p>
          </div>
        </div>
      </section>

      <section className="cta-band">
        <div>
          <h2>Ready to move your next load?</h2>
          <p className="muted">Create an account and get a quote in minutes.</p>
        </div>
        <Link to="/order" className="btn btn-primary btn-lg">
          Ship a load
        </Link>
      </section>
    </div>
  );
}
