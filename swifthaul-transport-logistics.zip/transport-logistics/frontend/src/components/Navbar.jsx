import React, { useState } from "react";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [open, setOpen] = useState(false);

  function handleLogout() {
    logout();
    setOpen(false);
    navigate("/");
  }

  const links = [
    { to: "/", label: "Home" },
    { to: "/services", label: "Services" },
    { to: "/about", label: "About" },
    { to: "/order", label: "Ship a Load" },
    { to: "/contact", label: "Contact" },
  ];

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-mark" aria-hidden="true">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none">
              <path d="M2 17V7a1 1 0 0 1 1-1h9v11H3a1 1 0 0 1-1-1Z" stroke="currentColor" strokeWidth="1.6" />
              <path d="M12 10h5.5L21 13.5V17a1 1 0 0 1-1 1h-8V10Z" stroke="currentColor" strokeWidth="1.6" />
              <circle cx="7" cy="18.5" r="1.6" stroke="currentColor" strokeWidth="1.4" />
              <circle cx="17" cy="18.5" r="1.6" stroke="currentColor" strokeWidth="1.4" />
            </svg>
          </span>
          SwiftHaul
        </Link>

        <button
          className="nav-toggle"
          aria-label="Toggle navigation"
          aria-expanded={open}
          onClick={() => setOpen((o) => !o)}
        >
          <span />
          <span />
          <span />
        </button>

        <nav className={`nav-links ${open ? "is-open" : ""}`}>
          {links.map((l) => (
            <NavLink
              key={l.to}
              to={l.to}
              end={l.to === "/"}
              className={({ isActive }) => "nav-link" + (isActive ? " active" : "")}
              onClick={() => setOpen(false)}
            >
              {l.label}
            </NavLink>
          ))}

          {user ? (
            <div className="nav-user">
              <NavLink
                to={user.role === "admin" ? "/admin" : "/dashboard"}
                className="btn btn-ghost btn-sm"
                onClick={() => setOpen(false)}
              >
                Dashboard
              </NavLink>
              <button className="btn btn-primary btn-sm" onClick={handleLogout}>
                Log out
              </button>
            </div>
          ) : (
            <div className="nav-user">
              <NavLink to="/login" className="btn btn-ghost btn-sm" onClick={() => setOpen(false)}>
                Log in
              </NavLink>
              <NavLink to="/register" className="btn btn-primary btn-sm" onClick={() => setOpen(false)}>
                Sign up
              </NavLink>
            </div>
          )}
        </nav>
      </div>
    </header>
  );
}
