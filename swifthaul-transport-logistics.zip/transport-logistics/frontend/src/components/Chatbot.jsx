import React, { useEffect, useRef, useState } from "react";
import api from "../api/axios";

const STARTER_PROMPTS = ["Track my shipment", "Get a price quote", "Delivery time?", "Talk to support"];

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [messages, setMessages] = useState([
    {
      from: "bot",
      text: "Hi, I'm the SwiftHaul enquiry assistant. Ask about pricing, tracking, vehicles or delivery times.",
    },
  ]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, open]);

  async function sendMessage(text) {
    const trimmed = text.trim();
    if (!trimmed || sending) return;

    setMessages((prev) => [...prev, { from: "user", text: trimmed }]);
    setInput("");
    setSending(true);

    try {
      const res = await api.post("/chatbot", { message: trimmed });
      setMessages((prev) => [...prev, { from: "bot", text: res.data.reply }]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { from: "bot", text: "Sorry, the enquiry service is unreachable right now. Please try the Contact page." },
      ]);
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="chatbot-root">
      {open && (
        <div className="chatbot-panel" role="dialog" aria-label="SwiftHaul enquiry chat">
          <div className="chatbot-header">
            <div>
              <strong>Enquiry Assistant</strong>
              <div className="chatbot-status">
                <span className="status-dot" /> Online
              </div>
            </div>
            <button className="chatbot-close" onClick={() => setOpen(false)} aria-label="Close chat">
              ×
            </button>
          </div>

          <div className="chatbot-messages" ref={scrollRef}>
            {messages.map((m, i) => (
              <div key={i} className={`chat-bubble ${m.from === "bot" ? "bot" : "user"}`}>
                {m.text}
              </div>
            ))}
            {sending && <div className="chat-bubble bot chat-typing">Typing…</div>}
          </div>

          {messages.length <= 1 && (
            <div className="chatbot-prompts">
              {STARTER_PROMPTS.map((p) => (
                <button key={p} className="prompt-chip" onClick={() => sendMessage(p)}>
                  {p}
                </button>
              ))}
            </div>
          )}

          <form
            className="chatbot-input-row"
            onSubmit={(e) => {
              e.preventDefault();
              sendMessage(input);
            }}
          >
            <input
              type="text"
              placeholder="Type your question…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button type="submit" className="btn btn-primary btn-sm" disabled={sending}>
              Send
            </button>
          </form>
        </div>
      )}

      <button
        className="chatbot-toggle"
        onClick={() => setOpen((o) => !o)}
        aria-label={open ? "Close enquiry chat" : "Open enquiry chat"}
      >
        {open ? "×" : "Ask us"}
      </button>
    </div>
  );
}
