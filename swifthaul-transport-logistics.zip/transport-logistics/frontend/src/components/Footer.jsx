import React from "react";

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div>
          <div className="brand brand-footer">SwiftHaul</div>
          <p className="muted">Road freight, planned and tracked end to end.</p>
        </div>
        <div className="footer-cols">
          <div>
            <h4>Company</h4>
            <p className="muted">About</p>
            <p className="muted">Services</p>
            <p className="muted">Contact</p>
          </div>
          <div>
            <h4>Support</h4>
            <p className="muted">support@swifthaul.com</p>
            <p className="muted">+977 1-555-0142</p>
          </div>
        </div>
      </div>
      <div className="footer-bottom">
        <span className="muted">© {new Date().getFullYear()} SwiftHaul. Prototype build — not a live service.</span>
      </div>
    </footer>
  );
}
