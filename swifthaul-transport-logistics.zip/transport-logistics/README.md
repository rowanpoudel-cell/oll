# SwiftHaul — Transport & Logistics Prototype

A full-stack prototype for a transport/logistics booking service:
- Auth (register/login) with **admin** and **user** roles (JWT)
- Public pages: **Home, Services, About, Contact**
- **Ship a Load** order form (creates a shipment request)
- **User Dashboard** — track your own orders by status
- **Admin Dashboard** — view every order, update status (pending → confirmed → in-transit → delivered/cancelled)
- Floating **enquiry Chatbot** (rule-based, no external API key needed)

Two separate folders, as requested:
```
transport-logistics/
├── backend/    Node.js + Express API (JWT auth, JSON file storage)
└── frontend/   React (Vite) app
```

> This is a **prototype**: the backend stores data in a local JSON file
> (`backend/data/db.json`), not a real database — enough to demo the full
> flow. Swap `backend/utils/db.js` for MongoDB/Postgres before going to
> production, and set a strong `JWT_SECRET`.

## 1. Backend setup

```bash
cd backend
npm install
cp .env.example .env      # edit JWT_SECRET if you like
npm run dev                # or: npm start
```
Runs on `http://localhost:5000`. On first run it seeds two demo accounts:

| Role  | Email                    | Password   |
|-------|---------------------------|------------|
| Admin | admin@swifthaul.com       | Admin@123  |
| User  | customer@swifthaul.com    | User@123   |

## 2. Frontend setup

Open a second terminal:
```bash
cd frontend
npm install
cp .env.example .env       # VITE_API_URL defaults to http://localhost:5000/api
npm run dev
```
Runs on `http://localhost:5173`.

## 3. Try it

1. Visit the site, browse Home / Services / About / Contact.
2. Log in with the demo **user** account, or register a new one, then go to
   **Ship a Load** to place an order — it will appear on your dashboard.
3. Log in with the demo **admin** account to see **all** orders and change
   their status from the Admin Dashboard.
4. Click **Ask us** in the bottom-right corner to try the enquiry chatbot
   (try "price", "track my order", "vehicle types", "delivery time").

## API overview

| Method | Route                     | Auth        | Description                     |
|--------|----------------------------|-------------|----------------------------------|
| POST   | /api/auth/register         | Public      | Create a user account            |
| POST   | /api/auth/login             | Public      | Log in, returns JWT              |
| GET    | /api/auth/me                 | User/Admin  | Current user profile             |
| POST   | /api/orders                  | User/Admin  | Create a shipment order          |
| GET    | /api/orders/mine              | User/Admin  | List my own orders               |
| GET    | /api/orders                    | Admin only  | List all orders                  |
| PATCH  | /api/orders/:id/status           | Admin only  | Update an order's status         |
| POST   | /api/chatbot                       | Public      | Ask the enquiry assistant        |
| POST   | /api/contact                         | Public      | Submit the contact form          |

## Next steps for a real deployment
- Replace the JSON file store with a real database.
- Add password reset / email verification.
- Add pagination + search on the admin order table.
- Connect the chatbot to a real AI API for open-ended enquiries.
- Add HTTPS, rate limiting, and input validation hardening.
